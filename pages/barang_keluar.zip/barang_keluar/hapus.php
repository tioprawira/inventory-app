<?php
include '../../auth/cek_login.php';
include '../../config/database.php';
include '../../auth/csrf.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(403);
    exit('Forbidden');
}

$id = $_POST['id'] ?? null;
$csrf = $_POST['csrf_token'] ?? null;

if (!$id || !validate_csrf($csrf)) {
    http_response_code(403);
    exit('Invalid CSRF');
}

/*
    OPTIONAL ENTERPRISE RULE:
    cek stok sebelum delete / rollback logic
*/

$stmt = $conn->prepare("DELETE FROM barang_keluar WHERE id = ?");
$stmt->execute([$id]);

echo json_encode([
    "status" => "success",
    "message" => "Data berhasil dihapus"
]);