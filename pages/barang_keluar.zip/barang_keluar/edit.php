<?php
include '../../auth/cek_login.php';
include '../../config/database.php';
include '../../templates/header.php';

$id = $_GET['id'];

$data = $conn->prepare("
    SELECT *
    FROM barang_keluar
    WHERE id=?
");

$data->execute([$id]);

$row = $data->fetch(PDO::FETCH_ASSOC);

$barang = $conn->query("
    SELECT *
    FROM barang
    ORDER BY nama_barang ASC
");

if(isset($_POST['update'])) {

    $barang_id = $_POST['barang_id'];
    $jumlah_baru = (int) $_POST['jumlah'];
    if ($jumlah_baru <= 0) {
        die('Jumlah Tidak Valid');
    }
    $diminta_oleh = $_POST['diminta_oleh'];
    $tanggal = $_POST['tanggal'];
    $keterangan = $_POST['keterangan'];

    // Kembalikan stok lama
    $kembalikan = $conn->prepare("
        UPDATE barang
        SET stok = stok + ?
        WHERE id=?
    ");

    $kembalikan->execute([
        $row['jumlah'],
        $row['barang_id']
    ]);

    // Cek stok baru
    $cek = $conn->prepare("
        SELECT stok
        FROM barang
        WHERE id=?
    ");

    $cek->execute([$barang_id]);

    $stokBarang = $cek->fetch(PDO::FETCH_ASSOC);

    if($jumlah_baru > $stokBarang['stok']) {

        echo "
        <script>
            alert('Stok tidak mencukupi');
        </script>
        ";

    } else {

        // Kurangi stok baru
        $kurangi = $conn->prepare("
            UPDATE barang
            SET stok = stok - ?
            WHERE id=?
        ");

        $kurangi->execute([
            $jumlah_baru,
            $barang_id
        ]);

        // Update transaksi
        $update = $conn->prepare("
            UPDATE barang_keluar
            SET barang_id=?,
                jumlah=?,
                diminta_oleh=?,
                tanggal=?,
                keterangan=?
            WHERE id=?
        ");

        $update->execute([
            $barang_id,
            $jumlah_baru,
            $diminta_oleh,
            $tanggal,
            $keterangan,
            $id
        ]);

        echo "
        <script>
            alert('Data berhasil diupdate');
            window.location='index.php';
        </script>
        ";
    }
}
?>

<div class="card shadow-sm">

    <div class="card-header bg-warning">
        Edit Barang Keluar
    </div>

    <div class="card-body">

        <form method="POST">

            <div class="mb-3">

                <label>Barang</label>

                <select name="barang_id"
                        class="form-select"
                        required>

                    <?php while($b = $barang->fetch(PDO::FETCH_ASSOC)): ?>

                        <option value="<?= $b['id']; ?>"
                            <?= ($b['id'] == $row['barang_id']) ? 'selected' : ''; ?>>

                            <?= $b['kode_barang']; ?>
                            -
                            <?= $b['nama_barang']; ?>

                        </option>

                    <?php endwhile; ?>

                </select>

            </div>

            <div class="mb-3">

                <label>Jumlah Keluar</label>

                <input type="number"
                       name="jumlah"
                       value="<?= $row['jumlah']; ?>"
                       class="form-control"
                       required>

            </div>

            <div class="mb-3">

                <label>Diminta Oleh</label>

                <input type="text"
                       name="diminta_oleh"
                       value="<?= $row['diminta_oleh']; ?>"
                       class="form-control"
                       required>

            </div>

            <div class="mb-3">

                <label>Tanggal</label>

                <input type="date"
                       name="tanggal"
                       value="<?= $row['tanggal']; ?>"
                       class="form-control"
                       required>

            </div>

            <div class="mb-3">

                <label>Keterangan</label>

                <textarea name="keterangan"
                          class="form-control"><?= $row['keterangan']; ?></textarea>

            </div>

            <button type="submit"
                    name="update"
                    class="btn btn-success">

                Update

            </button>

            <a href="index.php"
               class="btn btn-secondary">

                Kembali

            </a>

        </form>

    </div>

</div>

<?php include '../../templates/footer.php'; ?>