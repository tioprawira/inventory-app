<?php
include '../../auth/cek_login.php';
include '../../config/database.php';
include '../../templates/header.php';

$barang = $conn->query("
    SELECT * FROM barang
    ORDER BY nama_barang ASC
");

if(isset($_POST['simpan'])) {

    $barang_id = $_POST['barang_id'];
    $jumlah = (int) $_POST['jumlah'];
    if($jumlah <= 0){
        die('Jumlah tidak valid');
    }
    $diminta = $_POST['diminta_oleh'];
    $tanggal = $_POST['tanggal'];
    $keterangan = $_POST['keterangan'];

    $cek = $conn->prepare("
        SELECT stok
        FROM barang
        WHERE id=?
    ");

    $cek->execute([$barang_id]);

    $dataBarang = $cek->fetch(PDO::FETCH_ASSOC);

    if($jumlah > $dataBarang['stok']) {

        echo "
        <script>
            alert('Stok tidak mencukupi');
        </script>
        ";

    } else {

        $sql = "
            INSERT INTO barang_keluar
            (barang_id, jumlah, diminta_oleh, tanggal, keterangan)
            VALUES (?, ?, ?, ?, ?)
        ";

        $stmt = $conn->prepare($sql);

        $stmt->execute([
            $barang_id,
            $jumlah,
            $diminta,
            $tanggal,
            $keterangan
        ]);

        $updateStok = $conn->prepare("
            UPDATE barang
            SET stok = stok - ?
            WHERE id=?
        ");

        $updateStok->execute([
            $jumlah,
            $barang_id
        ]);

        echo "
        <script>
            alert('Barang keluar berhasil disimpan');
            window.location='index.php';
        </script>
        ";
    }
}
?>

<div class="card shadow-sm">

    <div class="card-header bg-danger text-white">
        Tambah Barang Keluar
    </div>

    <div class="card-body">

        <form method="POST">

            <div class="mb-3">

                <label>Barang</label>

                <select name="barang_id"
                        class="form-select"
                        required>

                    <option value="">
                        -- Pilih Barang --
                    </option>

                    <?php while($b = $barang->fetch(PDO::FETCH_ASSOC)): ?>

                        <option value="<?= $b['id']; ?>">

                            <?= $b['kode_barang']; ?>
                            -
                            <?= $b['nama_barang']; ?>
                            (Stok: <?= $b['stok']; ?>)

                        </option>

                    <?php endwhile; ?>

                </select>

            </div>

            <div class="mb-3">

                <label>Jumlah Keluar</label>

                <input type="number"
                       name="jumlah"
                       class="form-control"
                       required>

            </div>

            <div class="mb-3">

                <label>Diminta Oleh</label>

                <input type="text"
                       name="diminta_oleh"
                       class="form-control"
                       required>

            </div>

            <div class="mb-3">

                <label>Tanggal</label>

                <input type="date"
                       name="tanggal"
                       class="form-control"
                       required>

            </div>

            <div class="mb-3">

                <label>Keterangan</label>

                <textarea name="keterangan"
                          class="form-control"></textarea>

            </div>

            <button type="submit"
                    name="simpan"
                    class="btn btn-success">

                Simpan

            </button>

            <a href="index.php"
               class="btn btn-secondary">

                Kembali

            </a>

        </form>

    </div>

</div>

<?php include '../../templates/footer.php'; ?>